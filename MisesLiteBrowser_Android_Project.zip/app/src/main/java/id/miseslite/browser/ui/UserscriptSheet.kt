package id.miseslite.browser.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.miseslite.browser.core.userscript.RunAtStage
import id.miseslite.browser.core.userscript.UserscriptRunner

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserscriptBottomSheet(
    runner: UserscriptRunner,
    onRunImmediatelyInActiveTab: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scripts by runner.scripts.collectAsState()

    var scriptTitle by remember { mutableStateOf("") }
    var pastedCode by remember { mutableStateOf("") }
    var selectedStage by remember { mutableStateOf(RunAtStage.DOCUMENT_IDLE) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runner.importScriptFromUri(uri)
                .onSuccess { imported ->
                    Toast.makeText(context, "Berhasil memuat: \${imported.name}", Toast.LENGTH_SHORT).show()
                }
                .onFailure { err ->
                    Toast.makeText(context, "Gagal membaca file: \${err.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Userscript & Automation Runner",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                FilledTonalButton(
                    onClick = {
                        filePickerLauncher.launch(
                            arrayOf("application/javascript", "text/javascript", "application/json", "text/plain", "*/*")
                        )
                    }
                ) {
                    Text("+ Pilih File (.js / .json)")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = scriptTitle,
                onValueChange = { scriptTitle = it },
                label = { Text("Nama Script Automasi") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = pastedCode,
                onValueChange = { pastedCode = it },
                label = { Text("Paste Kode JavaScript / Userscript di sini...") },
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                minLines = 4,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedStage == RunAtStage.DOCUMENT_START,
                        onClick = { selectedStage = RunAtStage.DOCUMENT_START },
                        label = { Text("document_start") }
                    )
                    FilterChip(
                        selected = selectedStage == RunAtStage.DOCUMENT_IDLE,
                        onClick = { selectedStage = RunAtStage.DOCUMENT_IDLE },
                        label = { Text("document_idle") }
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = pastedCode.isNotBlank(),
                        onClick = { onRunImmediatelyInActiveTab(pastedCode) }
                    ) {
                        Text("Run Sekali")
                    }
                    Button(
                        enabled = pastedCode.isNotBlank(),
                        onClick = {
                            runner.addScriptFromRawText(scriptTitle, pastedCode, selectedStage)
                            scriptTitle = ""
                            pastedCode = ""
                            Toast.makeText(context, "Userscript disimpan & aktif!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("Simpan")
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            Text(
                text = "Daftar Script Terpasang (\${scripts.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(scripts, key = { it.id }) { item ->
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.name, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Stage: \${item.runAt.name} • Match: \${item.matchPattern}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Switch(
                                checked = item.isEnabled,
                                onCheckedChange = { runner.toggleScript(item.id, it) }
                            )
                            TextButton(onClick = { runner.deleteScript(item.id) }) {
                                Text("Hapus")
                            }
                        }
                    }
                }
            }
        }
    }
}
