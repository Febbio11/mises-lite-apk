package id.miseslite.browser.core.engine

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class BookmarkItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String,
    val createdAt: Long = System.currentTimeMillis()
)

class BookmarkManager(context: Context) {
    private val prefs = context.getSharedPreferences("mises_bookmarks", Context.MODE_PRIVATE)
    private val _bookmarks = MutableStateFlow<List<BookmarkItem>>(loadFromDisk())
    val bookmarks: StateFlow<List<BookmarkItem>> = _bookmarks.asStateFlow()

    fun addBookmark(title: String, url: String) {
        if (_bookmarks.value.any { it.url.equals(url, ignoreCase = true) }) return
        val updated = listOf(BookmarkItem(title = title.ifBlank { url }, url = url)) + _bookmarks.value
        _bookmarks.value = updated
        saveToDisk(updated)
    }

    fun removeBookmark(id: String) {
        val updated = _bookmarks.value.filterNot { it.id == id }
        _bookmarks.value = updated
        saveToDisk(updated)
    }

    private fun loadFromDisk(): List<BookmarkItem> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        val list = mutableListOf<BookmarkItem>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    BookmarkItem(
                        id = obj.optString("id"),
                        title = obj.optString("title"),
                        url = obj.optString("url"),
                        createdAt = obj.optLong("createdAt")
                    )
                )
            }
        }
        return list
    }

    private fun saveToDisk(items: List<BookmarkItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("url", item.url)
                    put("createdAt", item.createdAt)
                }
            )
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
