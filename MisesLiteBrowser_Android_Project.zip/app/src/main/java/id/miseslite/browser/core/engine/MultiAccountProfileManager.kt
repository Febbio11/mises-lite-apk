package id.miseslite.browser.core.engine

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebView
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BrowserAccountProfile(
    val id: String,
    val displayName: String,
    val badgeColorHex: Long
)

class MultiAccountProfileManager(private val context: Context) {
    private val _profiles = MutableStateFlow(
        listOf(
            BrowserAccountProfile("Default", "Default Profile", 0xFF4CAF50),
            BrowserAccountProfile("Profile_1", "Account #1 (Isolated)", 0xFF2196F3),
            BrowserAccountProfile("Profile_2", "Account #2 (Isolated)", 0xFFFF9800)
        )
    )
    val profiles: StateFlow<List<BrowserAccountProfile>> = _profiles.asStateFlow()

    @SuppressLint("RequiresFeature")
    fun bindProfileToWebView(webView: WebView, profileId: String, currentUrl: String? = null) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            val profileName = if (profileId == "Default") Profile.DEFAULT_PROFILE_NAME else "mises_isolated_\$profileId"
            val profile = ProfileStore.getInstance().getOrCreateProfile(profileName)
            WebViewCompat.setProfile(webView, profile.name)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            val isolationScript = """
                (function() {
                    if (window.__MISES_PROFILE_ISOLATED__) return;
                    window.__MISES_PROFILE_ISOLATED__ = '\$profileId';
                    const prefix = '__P_\${profileId}__';
                    const origSetItem = Storage.prototype.setItem;
                    const origGetItem = Storage.prototype.getItem;
                    Storage.prototype.setItem = function(k, v) { return origSetItem.call(this, prefix + k, v); };
                    Storage.prototype.getItem = function(k) { return origGetItem.call(this, prefix + k); };
                })();
            """.trimIndent()
            WebViewCompat.addDocumentStartJavaScript(webView, isolationScript, setOf("*"))
        }
    }
}
