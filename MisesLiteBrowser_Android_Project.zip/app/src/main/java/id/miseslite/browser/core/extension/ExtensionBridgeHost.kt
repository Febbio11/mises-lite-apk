package id.miseslite.browser.core.extension

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.webkit.WebView
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream

object CrxUnpacker {
    fun unpackCrxOrZip(crxFile: File, targetDir: File): File {
        if (!targetDir.exists()) targetDir.mkdirs()

        FileInputStream(crxFile).use { fis ->
            val buffered = BufferedInputStream(fis)
            buffered.mark(16)
            val magic = ByteArray(4)
            buffered.read(magic)

            if (String(magic, Charsets.US_ASCII) == "Cr24") {
                val versionBytes = ByteArray(4)
                buffered.read(versionBytes)
                val version = ByteBuffer.wrap(versionBytes).order(ByteOrder.LITTLE_ENDIAN).int

                when (version) {
                    2 -> {
                        val pubKeyLenBytes = ByteArray(4)
                        val sigLenBytes = ByteArray(4)
                        buffered.read(pubKeyLenBytes)
                        buffered.read(sigLenBytes)
                        val pubKeyLen = ByteBuffer.wrap(pubKeyLenBytes).order(ByteOrder.LITTLE_ENDIAN).int
                        val sigLen = ByteBuffer.wrap(sigLenBytes).order(ByteOrder.LITTLE_ENDIAN).int
                        buffered.skip((pubKeyLen + sigLen).toLong())
                    }
                    3 -> {
                        val headerLenBytes = ByteArray(4)
                        buffered.read(headerLenBytes)
                        val headerLen = ByteBuffer.wrap(headerLenBytes).order(ByteOrder.LITTLE_ENDIAN).int
                        buffered.skip(headerLen.toLong())
                    }
                    else -> error("Versi CRX tidak didukung: \$version")
                }
            } else {
                buffered.reset()
            }

            ZipInputStream(buffered).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val outFile = File(targetDir, entry.name)
                    if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath)) {
                        throw SecurityException("Terdeteksi percobaan Zip-Slip pada paket ekstensi!")
                    }
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        return targetDir
    }
}

class ExtensionBridgeHost(private val context: Context) {

    private val storagePrefs = context.getSharedPreferences("mises_ext_storage", Context.MODE_PRIVATE)

    companion object {
        val CHROME_AND_WEB3_POLYFILL_JS = """
            (function() {
                if (window.__MISES_EXT_BRIDGE_INSTALLED__) return;
                window.__MISES_EXT_BRIDGE_INSTALLED__ = true;

                const pendingCallbacks = new Map();
                let reqCounter = 1;

                const sendBridgeRequest = (action, data) => {
                    return new Promise((resolve, reject) => {
                        const requestId = 'req_' + (reqCounter++);
                        pendingCallbacks.set(requestId, { resolve, reject });
                        if (window.MisesExtensionBridge) {
                            window.MisesExtensionBridge.postMessage(JSON.stringify({
                                requestId,
                                action,
                                data
                            }));
                        } else {
                            reject(new Error('MisesExtensionBridge unavailable'));
                        }
                    });
                };

                if (window.MisesExtensionBridge) {
                    window.MisesExtensionBridge.onmessage = (event) => {
                        try {
                            const msg = JSON.parse(event.data);
                            if (msg.requestId && pendingCallbacks.has(msg.requestId)) {
                                const { resolve, reject } = pendingCallbacks.get(msg.requestId);
                                pendingCallbacks.delete(msg.requestId);
                                if (msg.error) reject(new Error(msg.error));
                                else resolve(msg.result);
                            }
                        } catch (e) {}
                    };
                }

                window.chrome = window.chrome || {};
                window.chrome.runtime = {
                    id: 'mises-lite-extension-host',
                    sendMessage: function(extensionIdOrMsg, maybeMsg, maybeCallback) {
                        const payload = (typeof extensionIdOrMsg === 'string') ? maybeMsg : extensionIdOrMsg;
                        const cb = (typeof maybeMsg === 'function') ? maybeMsg : maybeCallback;
                        const promise = sendBridgeRequest('RUNTIME_SEND_MESSAGE', payload);
                        if (typeof cb === 'function') {
                            promise.then(res => cb(res)).catch(() => cb(undefined));
                        }
                        return promise;
                    }
                };

                window.chrome.storage = {
                    local: {
                        get: function(keys, callback) {
                            const promise = sendBridgeRequest('STORAGE_GET', { keys });
                            if (typeof callback === 'function') promise.then(callback);
                            return promise;
                        },
                        set: function(items, callback) {
                            const promise = sendBridgeRequest('STORAGE_SET', { items });
                            if (typeof callback === 'function') promise.then(callback);
                            return promise;
                        }
                    }
                };

                if (!window.ethereum) {
                    window.ethereum = {
                        isMetaMask: true,
                        isMisesLite: true,
                        chainId: '0x1',
                        selectedAddress: null,
                        request: async function({ method, params }) {
                            return await sendBridgeRequest('WEB3_RPC_REQUEST', { method, params: params || [] });
                        }
                    };
                    window.dispatchEvent(new Event('ethereum#initialized'));
                }
            })();
        """.trimIndent()
    }

    @SuppressLint("RequiresFeature")
    fun attachToTabWebView(webView: WebView, tabId: String) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(
                webView,
                "MisesExtensionBridge",
                setOf("*")
            ) { _, message: WebMessageCompat, _: Uri, _, replyProxy: JavaScriptReplyProxy ->
                val raw = message.data ?: return@addWebMessageListener
                handleBridgeMessage(raw, replyProxy)
            }
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                webView,
                CHROME_AND_WEB3_POLYFILL_JS,
                setOf("*")
            )
        }
    }

    @SuppressLint("RequiresFeature")
    private fun handleBridgeMessage(rawJson: String, replyProxy: JavaScriptReplyProxy) {
        runCatching {
            val req = JSONObject(rawJson)
            val requestId = req.optString("requestId")
            val action = req.optString("action")
            val data = req.optJSONObject("data") ?: JSONObject()

            when (action) {
                "STORAGE_GET" -> {
                    val resultObj = JSONObject()
                    storagePrefs.all.forEach { (k, v) -> resultObj.put(k, v) }
                    sendReply(replyProxy, requestId, result = resultObj)
                }
                "STORAGE_SET" -> {
                    val items = data.optJSONObject("items") ?: JSONObject()
                    val editor = storagePrefs.edit()
                    items.keys().forEach { k -> editor.putString(k, items.opt(k)?.toString() ?: "") }
                    editor.apply()
                    sendReply(replyProxy, requestId, result = JSONObject().put("ok", true))
                }
                "WEB3_RPC_REQUEST" -> {
                    sendReply(replyProxy, requestId, result = "0x1")
                }
                else -> {
                    sendReply(replyProxy, requestId, result = JSONObject())
                }
            }
        }
    }

    @SuppressLint("RequiresFeature")
    private fun sendReply(
        replyProxy: JavaScriptReplyProxy,
        requestId: String,
        result: Any? = null,
        error: String? = null
    ) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return
        val res = JSONObject().apply {
            put("requestId", requestId)
            if (error != null) put("error", error) else put("result", result)
        }
        replyProxy.postMessage(res.toString())
    }
}
