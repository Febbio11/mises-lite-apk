package id.miseslite.browser

import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import id.miseslite.browser.core.engine.BookmarkManager
import id.miseslite.browser.core.engine.MultiAccountProfileManager
import id.miseslite.browser.core.engine.SmartTabManager
import id.miseslite.browser.core.extension.ExtensionBridgeHost
import id.miseslite.browser.core.inspector.NetworkTokenInspector
import id.miseslite.browser.core.userscript.UserscriptRunner
import id.miseslite.browser.ui.BrowserScreen

class MainActivity : ComponentActivity() {

    private lateinit var networkInspector: NetworkTokenInspector
    private lateinit var userscriptRunner: UserscriptRunner
    private lateinit var extensionBridgeHost: ExtensionBridgeHost
    private lateinit var profileManager: MultiAccountProfileManager
    private lateinit var bookmarkManager: BookmarkManager
    private lateinit var tabManager: SmartTabManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WebView.setWebContentsDebuggingEnabled(true)

        networkInspector = NetworkTokenInspector(applicationContext)
        userscriptRunner = UserscriptRunner(applicationContext)
        extensionBridgeHost = ExtensionBridgeHost(applicationContext)
        profileManager = MultiAccountProfileManager(applicationContext)
        bookmarkManager = BookmarkManager(applicationContext)

        tabManager = SmartTabManager(
            context = this,
            networkInspector = networkInspector,
            userscriptRunner = userscriptRunner,
            extensionBridgeHost = extensionBridgeHost,
            profileManager = profileManager
        )

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val activeId = tabManager.activeTabId.value
                val activeWebView = activeId?.let { tabManager.getOrCreateWebView(it) }
                if (activeWebView != null && activeWebView.canGoBack()) {
                    activeWebView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                BrowserScreen(
                    tabManager = tabManager,
                    inspector = networkInspector,
                    userscriptRunner = userscriptRunner,
                    bookmarkManager = bookmarkManager
                )
            }
        }
    }
}
