package id.miseslite.browser.core.engine

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.LruCache
import android.view.ViewGroup
import android.webkit.*
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import id.miseslite.browser.core.extension.ExtensionBridgeHost
import id.miseslite.browser.core.inspector.NetworkTokenInspector
import id.miseslite.browser.core.userscript.UserscriptRunner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.concurrent.Executors

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New Tab",
    val url: String = "https://www.google.com",
    val profileId: String = "Default",
    val isDesktopMode: Boolean = false,
    val isFrozen: Boolean = false,
    val savedState: Bundle? = null
)

object DesktopModeSpoofer {
    const val DESKTOP_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    const val MOBILE_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

    val DESKTOP_INJECTION_JS = """
        (function() {
            if (!window.__MISES_DESKTOP_ENABLED__) return;
            try {
                Object.defineProperty(navigator, 'platform', { get: () => 'Win32', configurable: true });
                Object.defineProperty(navigator, 'vendor', { get: () => 'Google Inc.', configurable: true });
                Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 0, configurable: true });
                Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8, configurable: true });
                Object.defineProperty(navigator, 'deviceMemory', { get: () => 8, configurable: true });

                const desktopUAData = {
                    brands: [
                        { brand: 'Google Chrome', version: '131' },
                        { brand: 'Chromium', version: '131' },
                        { brand: 'Not_A Brand', version: '24' }
                    ],
                    mobile: false,
                    platform: 'Windows',
                    getHighEntropyValues: async function(hints) {
                        return {
                            architecture: 'x86',
                            bitness: '64',
                            brands: this.brands,
                            fullVersionList: [
                                { brand: 'Google Chrome', version: '131.0.6778.86' },
                                { brand: 'Chromium', version: '131.0.6778.86' },
                                { brand: 'Not_A Brand', version: '24.0.0.0' }
                            ],
                            mobile: false,
                            model: '',
                            platform: 'Windows',
                            platformVersion: '15.0.0',
                            uaFullVersion: '131.0.6778.86',
                            wow64: false
                        };
                    },
                    toJSON: function() {
                        return { brands: this.brands, mobile: this.mobile, platform: this.platform };
                    }
                };
                Object.defineProperty(navigator, 'userAgentData', {
                    get: () => desktopUAData,
                    configurable: true
                });

                const screenOverrides = {
                    width: 1920, height: 1080,
                    availWidth: 1920, availHeight: 1040,
                    colorDepth: 24, pixelDepth: 24
                };
                for (const [key, val] of Object.entries(screenOverrides)) {
                    Object.defineProperty(window.screen, key, { get: () => val, configurable: true });
                }
                Object.defineProperty(window, 'outerWidth', { get: () => 1920, configurable: true });
                Object.defineProperty(window, 'outerHeight', { get: () => 1080, configurable: true });

                const enforceDesktopViewport = () => {
                    let meta = document.querySelector('meta[name="viewport"]');
                    if (!meta && document.head) {
                        meta = document.createElement('meta');
                        meta.name = 'viewport';
                        document.head.appendChild(meta);
                    }
                    if (meta) {
                        meta.setAttribute('content', 'width=1280, initial-scale=0.35, minimum-scale=0.1, maximum-scale=5.0, user-scalable=yes');
                    }
                };
                document.addEventListener('DOMContentLoaded', enforceDesktopViewport, { once: true });
            } catch (e) {}
        })();
    """.trimIndent()
}

object AdBlockFastFilter {
    private val blockedHosts = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "connect.facebook.net", "analytics.google.com",
        "ads.twitter.com", "pagead2.googlesyndication.com", "adnxs.com", "taboola.com"
    )

    fun isBlocked(url: Uri?): Boolean {
        val host = url?.host?.lowercase() ?: return false
        return blockedHosts.any { host == it || host.endsWith(".\$it") }
    }

    fun createEmptyResourceResponse(): WebResourceResponse {
        return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
    }
}

object ProxyControllerManager {
    fun applyProxy(host: String, port: Int, isSocks5: Boolean = false, onApplied: () -> Unit = {}) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        val scheme = if (isSocks5) "socks5" else "http"
        val proxyConfig = ProxyConfig.Builder()
            .addProxyRule("\$scheme://\$host:\$port")
            .addDirect()
            .build()
        ProxyController.getInstance().setProxyOverride(proxyConfig, Executors.newSingleThreadExecutor(), onApplied)
    }

    fun clearProxy(onCleared: () -> Unit = {}) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        ProxyController.getInstance().clearProxyOverride(Executors.newSingleThreadExecutor(), onCleared)
    }
}

class SmartTabManager(
    private val context: Context,
    private val networkInspector: NetworkTokenInspector,
    private val userscriptRunner: UserscriptRunner,
    private val extensionBridgeHost: ExtensionBridgeHost,
    private val profileManager: MultiAccountProfileManager
) {
    companion object {
        private const val MAX_LIVE_WEBVIEWS = 4
    }

    private val _tabs = MutableStateFlow<List<BrowserTab>>(emptyList())
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow<String?>(null)
    val activeTabId: StateFlow<String?> = _activeTabId.asStateFlow()

    private val webViewPool = object : LruCache<String, WebView>(MAX_LIVE_WEBVIEWS) {
        override fun entryRemoved(evicted: Boolean, key: String, oldValue: WebView, newValue: WebView?) {
            if (evicted) {
                val bundle = Bundle()
                oldValue.saveState(bundle)
                updateTabMetadata(key) { it.copy(savedState = bundle, isFrozen = true) }
                (oldValue.parent as? ViewGroup)?.removeView(oldValue)
                oldValue.stopLoading()
                oldValue.destroy()
            }
        }
    }

    fun createTab(
        initialUrl: String = "https://www.google.com",
        profileId: String = "Default",
        desktopMode: Boolean = false
    ): BrowserTab {
        val newTab = BrowserTab(url = initialUrl, profileId = profileId, isDesktopMode = desktopMode)
        _tabs.value = _tabs.value + newTab
        switchToTab(newTab.id)
        return newTab
    }

    fun switchToTab(tabId: String) {
        val previousId = _activeTabId.value
        if (previousId != null && previousId != tabId) {
            freezeTabInMemory(previousId)
        }
        _activeTabId.value = tabId
        val webView = getOrCreateWebView(tabId)
        resumeTabFromMemory(tabId, webView)
    }

    private fun freezeTabInMemory(tabId: String) {
        val webView = webViewPool.get(tabId) ?: return
        webView.onPause()
        webView.evaluateJavascript("window.__MISES_TAB_FROZEN__ = true;", null)
        updateTabMetadata(tabId) { it.copy(isFrozen = true) }
    }

    private fun resumeTabFromMemory(tabId: String, webView: WebView) {
        webView.onResume()
        webView.evaluateJavascript("window.__MISES_TAB_FROZEN__ = false;", null)
        updateTabMetadata(tabId) { it.copy(isFrozen = false) }
    }

    fun toggleDesktopMode(tabId: String) {
        val tab = _tabs.value.find { it.id == tabId } ?: return
        val nextMode = !tab.isDesktopMode
        updateTabMetadata(tabId) { it.copy(isDesktopMode = nextMode) }
        webViewPool.get(tabId)?.let { wv ->
            applyDesktopSettings(wv, nextMode)
            wv.reload()
        }
    }

    fun closeTab(tabId: String) {
        webViewPool.remove(tabId)?.let { wv ->
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        val remaining = _tabs.value.filterNot { it.id == tabId }
        _tabs.value = remaining
        if (_activeTabId.value == tabId) {
            _activeTabId.value = remaining.lastOrNull()?.id
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "RequiresFeature")
    fun getOrCreateWebView(tabId: String): WebView {
        webViewPool.get(tabId)?.let { return it }

        val tab = _tabs.value.find { it.id == tabId }
            ?: BrowserTab(id = tabId).also { _tabs.value = _tabs.value + it }

        val webView = WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                javaScriptCanOpenWindowsAutomatically = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                setSupportMultipleWindows(false)
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
            }

            profileManager.bindProfileToWebView(this, tab.profileId, tab.url)
            applyDesktopSettings(this, tab.isDesktopMode)

            networkInspector.attachToWebView(this, tabId)
            extensionBridgeHost.attachToTabWebView(this, tabId)
            userscriptRunner.attachDocumentStartScripts(this)

            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(
                    this,
                    DesktopModeSpoofer.DESKTOP_INJECTION_JS,
                    setOf("*")
                )
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    if (AdBlockFastFilter.isBlocked(request.url)) {
                        return AdBlockFastFilter.createEmptyResourceResponse()
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    val isDesktop = _tabs.value.find { it.id == tabId }?.isDesktopMode == true
                    view.evaluateJavascript("window.__MISES_DESKTOP_ENABLED__ = \$isDesktop;", null)
                    updateTabMetadata(tabId) { it.copy(url = url) }
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    updateTabMetadata(tabId) { it.copy(title = view.title ?: url, url = url) }
                    userscriptRunner.executeDocumentIdleScripts(view, url)
                    networkInspector.captureStorageAndCookies(view, url)
                }
            }
        }

        if (tab.savedState != null) {
            webView.restoreState(tab.savedState)
        } else {
            webView.loadUrl(tab.url)
        }

        webViewPool.put(tabId, webView)
        return webView
    }

    private fun applyDesktopSettings(webView: WebView, isDesktop: Boolean) {
        webView.settings.apply {
            userAgentString = if (isDesktop) {
                DesktopModeSpoofer.DESKTOP_USER_AGENT
            } else {
                DesktopModeSpoofer.MOBILE_USER_AGENT
            }
            useWideViewPort = isDesktop
            loadWithOverviewMode = isDesktop
        }
        webView.evaluateJavascript("window.__MISES_DESKTOP_ENABLED__ = \$isDesktop;", null)
    }

    private fun updateTabMetadata(tabId: String, updater: (BrowserTab) -> BrowserTab) {
        _tabs.value = _tabs.value.map { if (it.id == tabId) updater(it) else it }
    }
}
