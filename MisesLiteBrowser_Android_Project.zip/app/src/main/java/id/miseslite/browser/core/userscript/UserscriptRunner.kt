package id.miseslite.browser.core.userscript

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

enum class RunAtStage {
    DOCUMENT_START,
    DOCUMENT_IDLE
}

data class UserscriptItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val matchPattern: String = "*",
    val runAt: RunAtStage = RunAtStage.DOCUMENT_IDLE,
    val code: String,
    val isEnabled: Boolean = true
)

class UserscriptRunner(private val context: Context) {

    private val _scripts = MutableStateFlow<List<UserscriptItem>>(emptyList())
    val scripts: StateFlow<List<UserscriptItem>> = _scripts.asStateFlow()

    companion object {
        private val GM_API_POLYFILL_JS = """
            window.GM_setValue = function(key, val) {
                localStorage.setItem('__MISES_GM_' + key, JSON.stringify(val));
            };
            window.GM_getValue = function(key, defaultVal) {
                const raw = localStorage.getItem('__MISES_GM_' + key);
                return raw !== null ? JSON.parse(raw) : defaultVal;
            };
            window.GM_deleteValue = function(key) {
                localStorage.removeItem('__MISES_GM_' + key);
            };
            window.GM_log = function(...args) {
                console.log('[Userscript]', ...args);
            };
        """.trimIndent()
    }

    fun addScriptFromRawText(rawTitle: String, rawCode: String, preferredStage: RunAtStage? = null) {
        val parsedName = extractMeta(rawCode, "name") ?: rawTitle.ifBlank { "Custom Automation Script" }
        val parsedMatch = extractMeta(rawCode, "match") ?: "*"
        val metaRunAt = extractMeta(rawCode, "run-at")
        val stage = preferredStage ?: when {
            metaRunAt?.contains("document-start", ignoreCase = true) == true -> RunAtStage.DOCUMENT_START
            else -> RunAtStage.DOCUMENT_IDLE
        }

        val newItem = UserscriptItem(
            name = parsedName,
            matchPattern = parsedMatch,
            runAt = stage,
            code = rawCode,
            isEnabled = true
        )
        _scripts.value = _scripts.value + newItem
    }

    fun importScriptFromUri(uri: Uri): Result<UserscriptItem> = runCatching {
        val content = context.contentResolver.openInputStream(uri)?.use { stream ->
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
        } ?: error("Tidak dapat membaca file dari penyimpanan.")

        val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "imported_script.js"
        addScriptFromRawText(rawTitle = fileName, rawCode = content)
        _scripts.value.last()
    }

    fun toggleScript(scriptId: String, enabled: Boolean) {
        _scripts.value = _scripts.value.map {
            if (it.id == scriptId) it.copy(isEnabled = enabled) else it
        }
    }

    fun deleteScript(scriptId: String) {
        _scripts.value = _scripts.value.filterNot { it.id == scriptId }
    }

    @SuppressLint("RequiresFeature")
    fun attachDocumentStartScripts(webView: WebView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return

        WebViewCompat.addDocumentStartJavaScript(webView, GM_API_POLYFILL_JS, setOf("*"))

        _scripts.value
            .filter { it.isEnabled && it.runAt == RunAtStage.DOCUMENT_START }
            .forEach { script ->
                val wrappedJs = wrapUserscriptExecution(script)
                WebViewCompat.addDocumentStartJavaScript(webView, wrappedJs, setOf("*"))
            }
    }

    fun executeDocumentIdleScripts(webView: WebView, currentUrl: String) {
        _scripts.value
            .filter { it.isEnabled && it.runAt == RunAtStage.DOCUMENT_IDLE && matchesUrl(it.matchPattern, currentUrl) }
            .forEach { script ->
                webView.evaluateJavascript(wrapUserscriptExecution(script), null)
            }
    }

    private fun wrapUserscriptExecution(script: UserscriptItem): String {
        return """
            (function() {
                try {
                    \$GM_API_POLYFILL_JS
                    \${script.code}
                } catch (err) {
                    console.error('[MisesLite Userscript Error - \${script.name}]:', err);
                }
            })();
        """.trimIndent()
    }

    private fun matchesUrl(pattern: String, url: String): Boolean {
        if (pattern == "*" || pattern == "<all_urls>") return true
        val regexPattern = pattern.replace(".", "\\.").replace("*", ".*")
        return Regex("^\$regexPattern\$", RegexOption.IGNORE_CASE).matches(url)
    }

    private fun extractMeta(code: String, key: String): String? {
        val regex = Regex("@\$key\\s+(.+)")
        return regex.find(code)?.groupValues?.getOrNull(1)?.trim()
    }
}
