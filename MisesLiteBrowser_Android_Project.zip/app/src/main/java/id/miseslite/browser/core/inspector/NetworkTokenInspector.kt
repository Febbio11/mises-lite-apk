package id.miseslite.browser.core.inspector

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebView
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

data class ExtractedTokenItem(
    val id: String = UUID.randomUUID().toString(),
    val keyName: String,
    val tokenValue: String,
    val sourceType: String,
    val endpointUrl: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class CapturedNetworkCall(
    val id: String = UUID.randomUUID().toString(),
    val method: String,
    val url: String,
    val statusCode: Int,
    val requestHeaders: Map<String, String>,
    val responseBodyPreview: String,
    val timestamp: Long = System.currentTimeMillis()
)

class NetworkTokenInspector(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _extractedTokens = MutableStateFlow<List<ExtractedTokenItem>>(emptyList())
    val extractedTokens: StateFlow<List<ExtractedTokenItem>> = _extractedTokens.asStateFlow()

    private val _networkCalls = MutableStateFlow<List<CapturedNetworkCall>>(emptyList())
    val networkCalls: StateFlow<List<CapturedNetworkCall>> = _networkCalls.asStateFlow()

    private val tokenKeyRegex = Regex(
        pattern = "(refresh_token|access_token|id_token|auth_token|session_token|authorization|bearer|x-auth-token|csrf_token)",
        option = RegexOption.IGNORE_CASE
    )
    private val jwtValueRegex = Regex("eyJ[A-Za-z0-9_-]{10,}\\.eyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}")

    companion object {
        val NETWORK_HOOK_JS = """
            (function() {
                if (window.__MISES_NET_HOOKED__) return;
                window.__MISES_NET_HOOKED__ = true;

                const sendToKotlin = (payload) => {
                    try {
                        if (window.MisesInspectorBridge && window.MisesInspectorBridge.postMessage) {
                            window.MisesInspectorBridge.postMessage(JSON.stringify(payload));
                        }
                    } catch (e) {}
                };

                const origFetch = window.fetch;
                window.fetch = async function(...args) {
                    const reqInfo = args[0];
                    const reqInit = args[1] || {};
                    const url = (typeof reqInfo === 'string') ? reqInfo : (reqInfo.url || '');
                    const method = reqInit.method || (reqInfo && reqInfo.method) || 'GET';
                    const reqHeaders = {};

                    try {
                        if (reqInit.headers) {
                            if (reqInit.headers instanceof Headers) {
                                reqInit.headers.forEach((v, k) => reqHeaders[k] = v);
                            } else if (typeof reqInit.headers === 'object') {
                                Object.assign(reqHeaders, reqInit.headers);
                            }
                        }
                    } catch (e) {}

                    const response = await origFetch.apply(this, args);
                    try {
                        const clone = response.clone();
                        clone.text().then(bodyText => {
                            sendToKotlin({
                                type: 'NETWORK',
                                method: method,
                                url: url,
                                status: response.status,
                                reqHeaders: reqHeaders,
                                resBody: bodyText.slice(0, 16384)
                            });
                        }).catch(() => {});
                    } catch (e) {}
                    return response;
                };

                const origOpen = XMLHttpRequest.prototype.open;
                const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
                const origSend = XMLHttpRequest.prototype.send;

                XMLHttpRequest.prototype.open = function(method, url, ...rest) {
                    this.__misesMethod = method || 'GET';
                    this.__misesUrl = url || '';
                    this.__misesHeaders = {};
                    return origOpen.call(this, method, url, ...rest);
                };

                XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
                    if (this.__misesHeaders) {
                        this.__misesHeaders[header] = value;
                    }
                    return origSetHeader.call(this, header, value);
                };

                XMLHttpRequest.prototype.send = function(body) {
                    this.addEventListener('load', function() {
                        try {
                            const bodyText = (this.responseType === '' || this.responseType === 'text')
                                ? (this.responseText || '')
                                : JSON.stringify(this.response || {});
                            sendToKotlin({
                                type: 'NETWORK',
                                method: this.__misesMethod || 'GET',
                                url: this.__misesUrl || '',
                                status: this.status || 200,
                                reqHeaders: this.__misesHeaders || {},
                                resBody: bodyText.slice(0, 16384)
                            });
                        } catch (e) {}
                    });
                    return origSend.call(this, body);
                };
            })();
        """.trimIndent()
    }

    @SuppressLint("RequiresFeature")
    fun attachToWebView(webView: WebView, tabId: String) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(
                webView,
                "MisesInspectorBridge",
                setOf("*")
            ) { _, message: WebMessageCompat, sourceOrigin: Uri, _, _: JavaScriptReplyProxy ->
                val rawJson = message.data ?: return@addWebMessageListener
                scope.launch {
                    processIncomingPayload(rawJson, sourceOrigin.toString())
                }
            }
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, NETWORK_HOOK_JS, setOf("*"))
        }
    }

    fun captureStorageAndCookies(webView: WebView, pageUrl: String) {
        val rawCookie = CookieManager.getInstance().getCookie(pageUrl).orEmpty()
        if (rawCookie.isNotBlank()) {
            scope.launch {
                rawCookie.split(";").forEach { pair ->
                    val parts = pair.trim().split("=", limit = 2)
                    if (parts.size == 2) {
                        val k = parts[0].trim()
                        val v = parts[1].trim()
                        if (tokenKeyRegex.containsMatchIn(k) || jwtValueRegex.containsMatchIn(v)) {
                            appendToken(
                                ExtractedTokenItem(
                                    keyName = k,
                                    tokenValue = v,
                                    sourceType = "Cookie (HttpOnly/Browser)",
                                    endpointUrl = pageUrl
                                )
                            )
                        }
                    }
                }
            }
        }

        val dumpStorageJs = """
            (function() {
                try {
                    const dump = {};
                    for (let i = 0; i < localStorage.length; i++) {
                        const k = localStorage.key(i);
                        dump['LS:' + k] = localStorage.getItem(k);
                    }
                    for (let i = 0; i < sessionStorage.length; i++) {
                        const k = sessionStorage.key(i);
                        dump['SS:' + k] = sessionStorage.getItem(k);
                    }
                    if (window.MisesInspectorBridge) {
                        window.MisesInspectorBridge.postMessage(JSON.stringify({
                            type: 'STORAGE',
                            url: location.href,
                            items: dump
                        }));
                    }
                } catch (e) {}
            })();
        """.trimIndent()
        webView.evaluateJavascript(dumpStorageJs, null)
    }

    private fun processIncomingPayload(rawJson: String, originUrl: String) {
        runCatching {
            val root = JSONObject(rawJson)
            when (root.optString("type")) {
                "NETWORK" -> {
                    val method = root.optString("method", "GET")
                    val url = root.optString("url", originUrl)
                    val status = root.optInt("status", 200)
                    val headersObj = root.optJSONObject("reqHeaders") ?: JSONObject()
                    val resBody = root.optString("resBody", "")

                    val headerMap = mutableMapOf<String, String>()
                    headersObj.keys().forEach { key ->
                        val value = headersObj.optString(key)
                        headerMap[key] = value
                        if (tokenKeyRegex.containsMatchIn(key) || value.startsWith("Bearer ", ignoreCase = true)) {
                            appendToken(
                                ExtractedTokenItem(
                                    keyName = key,
                                    tokenValue = value,
                                    sourceType = "Request Header",
                                    endpointUrl = url
                                )
                            )
                        }
                    }

                    if (resBody.trim().startsWith("{")) {
                        extractTokensFromJson(JSONObject(resBody), url, "Response Body")
                    }

                    val call = CapturedNetworkCall(
                        method = method,
                        url = url,
                        statusCode = status,
                        requestHeaders = headerMap,
                        responseBodyPreview = resBody.take(600)
                    )
                    _networkCalls.value = (listOf(call) + _networkCalls.value).take(150)
                }

                "STORAGE" -> {
                    val url = root.optString("url", originUrl)
                    val items = root.optJSONObject("items") ?: return
                    items.keys().forEach { fullKey ->
                        val rawValue = items.optString(fullKey)
                        val sourceLabel = if (fullKey.startsWith("LS:")) "LocalStorage" else "SessionStorage"
                        val cleanKey = fullKey.removePrefix("LS:").removePrefix("SS:")

                        if (tokenKeyRegex.containsMatchIn(cleanKey) || jwtValueRegex.containsMatchIn(rawValue)) {
                            appendToken(
                                ExtractedTokenItem(
                                    keyName = cleanKey,
                                    tokenValue = rawValue,
                                    sourceType = sourceLabel,
                                    endpointUrl = url
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    private fun extractTokensFromJson(json: JSONObject, endpointUrl: String, sourceType: String) {
        json.keys().forEach { key ->
            val value = json.opt(key)
            when (value) {
                is JSONObject -> extractTokensFromJson(value, endpointUrl, sourceType)
                is String -> {
                    if (value.isNotBlank() && (tokenKeyRegex.containsMatchIn(key) || jwtValueRegex.containsMatchIn(value))) {
                        appendToken(
                            ExtractedTokenItem(
                                keyName = key,
                                tokenValue = value,
                                sourceType = sourceType,
                                endpointUrl = endpointUrl
                            )
                        )
                    }
                }
            }
        }
    }

    private fun appendToken(item: ExtractedTokenItem) {
        val current = _extractedTokens.value
        if (current.none { it.keyName == item.keyName && it.tokenValue == item.tokenValue }) {
            _extractedTokens.value = (listOf(item) + current).take(100)
        }
    }

    fun copyToClipboard(label: String, value: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
    }

    fun clearLogs() {
        _extractedTokens.value = emptyList()
        _networkCalls.value = emptyList()
    }
}
