package id.miseslite.browser.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import id.miseslite.browser.core.inspector.ExtractedTokenItem
import id.miseslite.browser.core.inspector.NetworkTokenInspector

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InspectorBottomSheet(
    inspector: NetworkTokenInspector,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val tokens by inspector.extractedTokens.collectAsState()
    val networkCalls by inspector.networkCalls.collectAsState()

    var selectedFilter by remember { mutableStateOf("ALL") }
    var searchKeyword by remember { mutableStateOf("") }
    var activeTabIndex by remember { mutableIntStateOf(0) }

    val quickFilters = listOf("ALL", "refresh_token", "access_token", "Bearer", "Cookie")

    val filteredTokens = remember(tokens, selectedFilter, searchKeyword) {
        tokens.filter { item ->
            val matchesChip = selectedFilter == "ALL" ||
                item.keyName.contains(selectedFilter, ignoreCase = true) ||
                item.tokenValue.contains(selectedFilter, ignoreCase = true) ||
                item.sourceType.contains(selectedFilter, ignoreCase = true)
            val matchesSearch = searchKeyword.isBlank() ||
                item.keyName.contains(searchKeyword, ignoreCase = true) ||
                item.tokenValue.contains(searchKeyword, ignoreCase = true) ||
                item.endpointUrl.contains(searchKeyword, ignoreCase = true)
            matchesChip && matchesSearch
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Easy DevTools & Token Inspector",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = { inspector.clearLogs() }) {
                    Text("Clear")
                }
            }

            TabRow(selectedTabIndex = activeTabIndex) {
                Tab(
                    selected = activeTabIndex == 0,
                    onClick = { activeTabIndex = 0 },
                    text = { Text("Tokens (\${filteredTokens.size})") }
                )
                Tab(
                    selected = activeTabIndex == 1,
                    onClick = { activeTabIndex = 1 },
                    text = { Text("Network (\${networkCalls.size})") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = searchKeyword,
                onValueChange = { searchKeyword = it },
                placeholder = { Text("Cari refresh_token, Bearer, domain...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (activeTabIndex == 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickFilters.forEach { chip ->
                        FilterChip(
                            selected = selectedFilter == chip,
                            onClick = { selectedFilter = chip },
                            label = { Text(chip, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredTokens, key = { it.id }) { tokenItem ->
                        TokenCardItem(
                            item = tokenItem,
                            onCopy = {
                                inspector.copyToClipboard(tokenItem.keyName, tokenItem.tokenValue)
                                Toast.makeText(
                                    context,
                                    "Tersalin: \${tokenItem.keyName}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(networkCalls, key = { it.id }) { call ->
                        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "[\${call.statusCode}] \${call.method} • \${call.url}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (call.responseBodyPreview.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = call.responseBodyPreview,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = FontFamily.Monospace,
                                        maxLines = 4,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(onClick = {
                                        inspector.copyToClipboard("Response Body", call.responseBodyPreview)
                                        Toast.makeText(context, "Response disalin!", Toast.LENGTH_SHORT).show()
                                    }) {
                                        Text("1-Klik Copy Body")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TokenCardItem(
    item: ExtractedTokenItem,
    onCopy: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AssistChip(
                    onClick = {},
                    label = { Text("\${item.keyName} • \${item.sourceType}") }
                )
                Button(onClick = onCopy) {
                    Text("1-Klik Copy")
                }
            }
            Text(
                text = item.tokenValue,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(vertical = 4.dp)
            )
            Text(
                text = item.endpointUrl,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
