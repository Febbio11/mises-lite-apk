package id.miseslite.browser.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import id.miseslite.browser.core.engine.BookmarkManager
import id.miseslite.browser.core.engine.SmartTabManager
import id.miseslite.browser.core.inspector.NetworkTokenInspector
import id.miseslite.browser.core.userscript.UserscriptRunner

@Composable
fun BrowserScreen(
    tabManager: SmartTabManager,
    inspector: NetworkTokenInspector,
    userscriptRunner: UserscriptRunner,
    bookmarkManager: BookmarkManager
) {
    val tabs by tabManager.tabs.collectAsState()
    val activeTabId by tabManager.activeTabId.collectAsState()
    val extractedTokens by inspector.extractedTokens.collectAsState()

    val activeTab = remember(tabs, activeTabId) {
        tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
    }

    var urlInput by remember(activeTab?.url) { mutableStateOf(activeTab?.url ?: "https://") }
    var showInspectorSheet by remember { mutableStateOf(false) }
    var showUserscriptSheet by remember { mutableStateOf(false) }
    var showTabSwitcherSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (tabs.isEmpty()) {
            tabManager.createTab("https://www.google.com")
        }
    }

    Scaffold(
        topBar = {
            Surface(tonalElevation = 3.dp) {
                Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Masukkan URL atau kata kunci...") }
                        )
                        Button(
                            onClick = {
                                val id = activeTab?.id ?: return@Button
                                val formatted = if (urlInput.startsWith("http")) urlInput else "https://\$urlInput"
                                tabManager.getOrCreateWebView(id).loadUrl(formatted)
                            }
                        ) {
                            Text("Go")
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = activeTab?.isDesktopMode == true,
                            onClick = { activeTab?.id?.let { tabManager.toggleDesktopMode(it) } },
                            label = { Text("Desktop") }
                        )

                        BadgedBox(
                            badge = {
                                if (extractedTokens.isNotEmpty()) {
                                    Badge { Text("\${extractedTokens.size}") }
                                }
                            }
                        ) {
                            FilledTonalButton(onClick = { showInspectorSheet = true }) {
                                Text("Tokens")
                            }
                        }

                        FilledTonalButton(onClick = { showUserscriptSheet = true }) {
                            Text("Script")
                        }

                        OutlinedButton(onClick = { showTabSwitcherSheet = true }) {
                            Text("Tab (\${tabs.size})")
                        }

                        IconButton(onClick = { showSettingsSheet = true }) {
                            Text("⚙️")
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            val currentId = activeTab?.id
            if (currentId != null) {
                key(currentId) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            FrameLayout(ctx).apply {
                                val wv = tabManager.getOrCreateWebView(currentId)
                                (wv.parent as? ViewGroup)?.removeView(wv)
                                addView(wv)
                            }
                        }
                    )
                }
            }
        }
    }

    if (showInspectorSheet) {
        InspectorBottomSheet(
            inspector = inspector,
            onDismiss = { showInspectorSheet = false }
        )
    }

    if (showUserscriptSheet) {
        UserscriptBottomSheet(
            runner = userscriptRunner,
            onRunImmediatelyInActiveTab = { rawJs ->
                activeTab?.id?.let { id ->
                    tabManager.getOrCreateWebView(id).evaluateJavascript(rawJs, null)
                }
            },
            onDismiss = { showUserscriptSheet = false }
        )
    }

    if (showTabSwitcherSheet) {
        TabSwitcherBottomSheet(
            tabManager = tabManager,
            onDismiss = { showTabSwitcherSheet = false }
        )
    }

    if (showSettingsSheet) {
        ExtensionAndSettingsSheet(
            bookmarkManager = bookmarkManager,
            currentTitle = activeTab?.title ?: "",
            currentUrl = activeTab?.url ?: "",
            onNavigateToUrl = { targetUrl ->
                activeTab?.id?.let { id ->
                    tabManager.getOrCreateWebView(id).loadUrl(targetUrl)
                }
            },
            onDismiss = { showSettingsSheet = false }
        )
    }
}
