package id.miseslite.browser.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import id.miseslite.browser.core.engine.BookmarkManager
import id.miseslite.browser.core.engine.ProxyControllerManager
import id.miseslite.browser.core.engine.SmartTabManager
import id.miseslite.browser.core.extension.CrxUnpacker
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabSwitcherBottomSheet(
    tabManager: SmartTabManager,
    onDismiss: () -> Unit
) {
    val tabs by tabManager.tabs.collectAsState()
    val activeTabId by tabManager.activeTabId.collectAsState()

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tab Aktif & Tersuspensi (\${tabs.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        tabManager.createTab(profileId = "Profile_\${tabs.size}")
                        onDismiss()
                    }) {
                        Text("+ Tab Akun Baru")
                    }
                    Button(onClick = {
                        tabManager.createTab()
                        onDismiss()
                    }) {
                        Text("+ Tab")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tabs, key = { it.id }) { tab ->
                    val isSelected = tab.id == activeTabId
                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                tabManager.switchToTab(tab.id)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isSelected) "● \${tab.title}" else tab.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "[\${tab.profileId}] \${tab.url} • \${if (tab.isFrozen) "RAM Frozen" else "Live"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            TextButton(onClick = { tabManager.closeTab(tab.id) }) {
                                Text("Tutup")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtensionAndSettingsSheet(
    bookmarkManager: BookmarkManager,
    currentTitle: String,
    currentUrl: String,
    onNavigateToUrl: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val bookmarks by bookmarkManager.bookmarks.collectAsState()

    var proxyHost by remember { mutableStateOf("") }
    var proxyPort by remember { mutableStateOf("8080") }
    var isSocks5 by remember { mutableStateOf(false) }
    var installedExtensions by remember {
        mutableStateOf(
            File(context.filesDir, "extensions").listFiles()?.map { it.name }.orEmpty()
        )
    }

    val crxPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val tempCrx = File(context.cacheDir, "temp_ext_\${System.currentTimeMillis()}.crx")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempCrx).use { output -> input.copyTo(output) }
                }
                val extId = "ext_\${System.currentTimeMillis()}"
                val outDir = File(context.filesDir, "extensions/\$extId")
                CrxUnpacker.unpackCrxOrZip(tempCrx, outDir)
                tempCrx.delete()
                installedExtensions = File(context.filesDir, "extensions").listFiles()?.map { it.name }.orEmpty()
                Toast.makeText(context, "Ekstensi berhasil diekstrak: \$extId", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(context, "Gagal memasang CRX: \${err.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(16.dp)
        ) {
            Text(
                text = "Ekstensi (.crx), Proxy & Bookmark",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Chrome Extensions (\${installedExtensions.size})", fontWeight = FontWeight.SemiBold)
                        Button(onClick = { crxPickerLauncher.launch(arrayOf("*/*")) }) {
                            Text("+ Muat .CRX / .ZIP")
                        }
                    }
                    if (installedExtensions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Terpasang: \${installedExtensions.joinToString(", ")}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Pengaturan Proxy (HTTP / SOCKS5)", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = proxyHost,
                            onValueChange = { proxyHost = it },
                            label = { Text("Host / IP") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = proxyPort,
                            onValueChange = { proxyPort = it },
                            label = { Text("Port") },
                            singleLine = true,
                            modifier = Modifier.width(100.dp)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = isSocks5, onCheckedChange = { isSocks5 = it })
                            Text("SOCKS5")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                ProxyControllerManager.clearProxy {}
                            }) {
                                Text("Reset")
                            }
                            Button(onClick = {
                                val portNum = proxyPort.toIntOrNull() ?: 8080
                                if (proxyHost.isNotBlank()) {
                                    ProxyControllerManager.applyProxy(proxyHost, portNum, isSocks5) {}
                                }
                            }) {
                                Text("Terapkan")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Daftar Bookmark (\${bookmarks.size})", fontWeight = FontWeight.SemiBold)
                FilledTonalButton(onClick = {
                    bookmarkManager.addBookmark(currentTitle, currentUrl)
                    Toast.makeText(context, "Halaman disimpan ke Bookmark", Toast.LENGTH_SHORT).show()
                }) {
                    Text("+ Simpan Halaman Ini")
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(bookmarks, key = { it.id }) { bm ->
                    OutlinedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onNavigateToUrl(bm.url)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(bm.title, fontWeight = FontWeight.Medium, maxLines = 1)
                                Text(bm.url, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                            TextButton(onClick = { bookmarkManager.removeBookmark(bm.id) }) {
                                Text("Hapus")
                            }
                        }
                    }
                }
            }
        }
    }
}
