# Mises Lite & Automation Browser (Android Native)

Project Android Studio siap build menjadi file `.apk`.

## Cara 1: Build Otomatis di Cloud via GitHub (Tanpa Laptop / Tanpa Install Android Studio — Bisa dari HP!)
1. Buat akun dan repository baru di [GitHub](https://github.com/new).
2. Ekstrak isi file `MisesLiteBrowser_Android_Project.zip` ini lalu upload seluruh file/foldernya ke repository GitHub tersebut (pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload).
3. Buka menu **Actions** di repository GitHub Anda, klik workflow **Build Mises Lite Browser APK**, lalu klik tombol **Run workflow**.
4. Tunggu sekitar 3–4 menit hingga centang hijau muncul, lalu unduh file **`Mises-Lite-Browser-APK`** di bagian **Artifacts** paling bawah. Di dalamnya terdapat file `app-release.apk` (~6 MB) yang siap di-install langsung di HP Android Anda!

## Cara 2: Build Menggunakan Android Studio di Laptop / PC
1. Ekstrak `MisesLiteBrowser_Android_Project.zip` ke sebuah folder.
2. Buka **Android Studio** -> pilih **Open** -> arahkan ke folder hasil ekstrak tadi.
3. Tunggu proses *Gradle Sync* selesai, lalu klik menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. File `.apk` siap diambil di `app/build/outputs/apk/debug/app-debug.apk`.
